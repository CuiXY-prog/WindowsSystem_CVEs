# cve-2020-1350
Bash Proof-of-Concept (PoC) script to exploit SIGRed (CVE-2020-1350).

Achieves Domain Admin on Domain Controllers running Windows Server 2003 up to Windows Server 2019.

====================================================

To run, from a Linux host on a Windows Active Directory Network:

~# chmod +x cve-2020-1350.sh

~# ./cve-2020-1350.sh 10.0.0.1

=====================================================

References:

CVE-2020-1350 | Windows DNS Server Remote Code Execution Vulnerability

https://portal.msrc.microsoft.com/en-US/security-guidance/advisory/CVE-2020-1350

-----

July 2020 Security Update: CVE-2020-1350 Vulnerability in Windows Domain Name System (DNS) Server

https://msrc-blog.microsoft.com/2020/07/14/july-2020-security-update-cve-2020-1350-vulnerability-in-windows-domain-name-system-dns-server/

-----

SIGRed – Resolving Your Way into Domain Admin: Exploiting a 17 Year-old Bug in Windows DNS Servers

https://research.checkpoint.com/2020/resolving-your-way-into-domain-admin-exploiting-a-17-year-old-bug-in-windows-dns-servers/
