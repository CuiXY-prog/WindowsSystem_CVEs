# CVE-2020-0796 Remote overflow POC

POC to check for CVE-2020-0796 / "SMBGhost"  

# Usage

Make sure Python is installed, then run `cve-2020-0796.py`.

![demo](demo.gif)