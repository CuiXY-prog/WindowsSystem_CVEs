# CVE-2021-31955 Windows Kernel Information Disclosure POC

The exploit works on all 64-bit vulnerable targets.

### unpatched system
![UnPatched](unpatched.png)

### patched system
![Patched](patched.png)
