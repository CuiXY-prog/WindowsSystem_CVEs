# CVE-2023-21823 Reverse Shell for Windows

This repository contains C code that implements a reverse shell for the Windows operating system. A reverse shell allows for remote system control using the command-line, providing the ability to execute commands on the infected machine.

## Important

Using this code for illegal purposes or without the permission of the system owner is unlawful and against ethical principles. This code is provided for educational and research purposes only.

## Building

To build the project, you will need a C compiler such as [MinGW](http://www.mingw.org/) or [Microsoft Visual Studio](https://visualstudio.microsoft.com/).

## MinGW

1. Install MinGW if you don't have it already.
2. Open the command prompt and navigate to the directory containing the source code.
3. Run the following command to build the project:

```bash
gcc -o reverse_shell.exe main.c -lws2_32
```

## Microsoft Visual Studio
1. Install Visual Studio if you don't have it already.
2. Create a new C project, and then add the source code to the project.
3. In the project settings, add the ws2_32.lib library.
4. Build the project.

## Usage
Before using the reverse shell:

1. Replace the IP address ("192.168.0.1") with your own IP address where the port will be listened to.
2. Replace the port number (1234) with the port number you want to use for listening.

To run the reverse shell:

1. On your computer, open a port for listening using a tool such as netcat. For example:
```bash
nc -l -p 1234
```
2. Execute the compiled `reverse_shell.exe` file on the target computer.
After this, you will have remote access to the target computer's command-line via the specified port.
