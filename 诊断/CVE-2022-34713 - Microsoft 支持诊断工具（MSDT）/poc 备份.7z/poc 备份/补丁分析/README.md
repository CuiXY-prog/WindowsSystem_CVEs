# Patch analysis for CVE-2022-34713 also known as DogWalk vulnerability 

My [first look](https://twitter.com/j00sean/status/1557189330753421314) at the patch was not too much wrong. Though there are some parts which are tricky to understand without taking a look at the pre-patch version for sdiageng.dll.

## Versions

The versions used for diffing the patch (located at C:\Windows\System32\sdiageng.dll) have been:

+ MD5: 3D6A5C5734C81BBEAC96E67F7A21441B (pre-patch)
+ MD5: E299824ED9FF00FF6EC8CB4EB69CBE07 (post-patch)

## Analysis

[@matalaz's diaphora](https://github.com/joxeankoret/diaphora) makes our life really easy :-)

At first look in the partial matches provided by diaphora, we will see:

![alt text](<./shots/sdiageng-partial-matches.png>)

What indicates most of fun happens in the function sdiageng!SdpCopyDirectory. Taking a look at the pseudo-code diffing made by diaphora, **the first change we find is the "magic" registry key** that [was already introduced with the Follina patches](https://twitter.com/j00sean/status/1557201056874086410):

![alt text](<./shots/pseudocode-diffing-patch.png>)

**So setting this registry key, DogWalk and Follina vulnerabilities are active again**.

```js
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\ScriptedDiagnostics]
"TurnOffCheck"=dword:00000001
```

![alt text](<./shots/dogwalk-follina-regkey-turnoffcheck.png>)


The pseudo-code for this function sdiageng!SdpCopyDirectory is something like this:

```cpp

__int64 __fastcall SdpCopyDirectory(const unsigned __int16 *aPckSource, const unsigned __int16 *aTmpSDiagPath)
{
  const unsigned __int16 *lsTmpSDiagPath; // r13
  const unsigned __int16 *lPckSource; // r12
  char bFlagTurnOffCheck; // di
  LSTATUS lRes1; // eax
  __int64 v6; // r8
  unsigned __int64 lRes2; // r9
  char *hFind; // r15
  __int64 itraceCode1; // r8
  int dwLastError5; // er9
  unsigned int dwLastError2; // ebx
  LSTATUS dwRet1; // eax
  __int64 v13; // r8
  signed int dwRet2; // ebx
  wchar_t *sWebDavFile; // rsi
  wchar_t *sTmpSDiagFile; // r14
  int dwLastError3; // er9
  __int64 itraceCode2; // r8
  signed int dwLastError4; // eax
  signed int dwLastError6; // eax
  __int64 v21; // r8
  signed int dwLastError1; // eax
  BYTE Data[4]; // [rsp+30h] [rbp-D0h]
  DWORD cbData; // [rsp+34h] [rbp-CCh]
  DWORD Type; // [rsp+38h] [rbp-C8h]
  HKEY hKey; // [rsp+40h] [rbp-C0h]
  struct _WIN32_FIND_DATAW FindFileData; // [rsp+50h] [rbp-B0h]
  wil::details::in1diag3 *retaddr; // [rsp+2E8h] [rbp+1E8h]

  lsTmpSDiagPath = aTmpSDiagPath;
  lPckSource = aPckSource;
  if ( byte_7FFC50EF27F8 )
  {
    bFlagTurnOffCheck = byte_7FFC50EF2858;
    goto DEBUG_TRACE1;
  }
  hKey = 0i64;                                  // TurnOffCheck Registry key turned on? #DogWalk vuln is ok ¯\_(ツ)_/¯
  lRes1 = RegOpenKeyExW(
            HKEY_LOCAL_MACHINE,
            L"Software\\Policies\\Microsoft\\Windows\\ScriptedDiagnostics",
            0,
            0x20019u,
            &hKey);
  lRes2 = lRes1 | 0x80070000;
  if ( lRes1 <= 0 )
    lRes2 = lRes1;
  if ( (lRes2 & 0x80000000) != 0i64 )
  {
    wil::details::in1diag3::_Log_Hr(retaddr, 0x7EA, v6, lRes2);
TURNOFFCHECK_OFF:
    bFlagTurnOffCheck = 1;
    goto DEBUG_TRACE1;
  }
  if ( !hKey )
    goto TURNOFFCHECK_OFF;
  *Data = 0;
  Type = 4;
  cbData = 4;
  dwRet1 = RegQueryValueExW(hKey, L"TurnOffCheck", 0i64, &Type, Data, &cbData);
  dwRet2 = dwRet1 | 0x80070000;
  if ( dwRet1 <= 0 )
    dwRet2 = dwRet1;
  if ( dwRet2 < 0 )
    wil::details::in1diag3::_Log_Hr(retaddr, 0x7FB, v13, dwRet2);
  if ( hKey )
    RegCloseKey(hKey);
  if ( dwRet2 < 0 || (bFlagTurnOffCheck = 0, !*Data) )
    bFlagTurnOffCheck = 1;
  byte_7FFC50EF2858 = bFlagTurnOffCheck;
  byte_7FFC50EF27F8 = 1;
DEBUG_TRACE1:
  hFind = 0i64;
  if ( !lPckSource )                            // Check arguments for errors
  {
    itraceCode1 = 2103i64;
DEBUG_TRACE2:
    dwLastError5 = -2147024809;
DEBUG_TRACE3:
    dwLastError2 = dwLastError5;
    SdpDebugTrace(1u, L"SdpCopyDirectory", itraceCode1, dwLastError5);
    return dwLastError2;
  }
  if ( !lsTmpSDiagPath )
  {
    itraceCode1 = 2104i64;
    goto DEBUG_TRACE2;
  }
  sWebDavFile = operator new[](0x208ui64);
  if ( !sWebDavFile )
  {
    dwLastError5 = -2147024882;
    itraceCode1 = 2107i64;
    goto DEBUG_TRACE3;
  }
  sTmpSDiagFile = operator new[](0x208ui64);
  if ( !sTmpSDiagFile )
  {
    dwLastError3 = -2147024882;
    itraceCode2 = 2110i64;
    dwLastError2 = -2147024882;
    goto DEBUG_TRACE5;
  }
  dwLastError4 = StringCchPrintfW(sWebDavFile, 260i64, L"%s\\*", lPckSource);
  dwLastError2 = dwLastError4;
  if ( dwLastError4 < 0 )
  {
    itraceCode2 = 2113i64;
    goto DEBUG_TRACE4;
  }
  hFind = FindFirstFileW(sWebDavFile, &FindFileData);// Search for file or directory in WebDavRoot\*
  if ( (hFind - 1) <= 0xFFFFFFFFFFFFFFFDui64 )
  {
    do
    {
      if ( !(FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) )// Isn't it a directory? Setup sWebDavFile and sTmpSDiagFile
      {
        dwLastError4 = StringCchPrintfW(sWebDavFile, 260i64, L"%s\\%s", lPckSource, FindFileData.cFileName);
        dwLastError2 = dwLastError4;
        if ( dwLastError4 < 0 )
        {
          itraceCode2 = 2134i64;
DEBUG_TRACE4:
          dwLastError3 = dwLastError4;
DEBUG_TRACE5:
          SdpDebugTrace(1u, L"SdpCopyDirectory", itraceCode2, dwLastError3);
          break;
        }
        dwLastError4 = StringCchPrintfW(sTmpSDiagFile, 260i64, L"%s\\%s", lsTmpSDiagPath, FindFileData.cFileName);
        dwLastError2 = dwLastError4;
        if ( dwLastError4 < 0 )
        {
          itraceCode2 = 0x85Di64;
          goto DEBUG_TRACE4;
        }
        if ( bFlagTurnOffCheck )                // Is TurnOffCheck turned off?
        {
          *Data = 0;
          dwLastError6 = SdpIsSubDirectory(lPckSource, sWebDavFile, Data);// Check if any WebDav file is sub-directory of package source 
          if ( dwLastError6 < 0 )
            goto REPORT_FAILURE;
          if ( !*Data )
            continue;
          *Data = 0;
          dwLastError6 = SdpIsSubDirectory(lsTmpSDiagPath, sTmpSDiagFile, Data);// Check if any file at %TMP\SDIAG_random-clsid is sub-directory of folder %TMP%\SDIAG_random-clsid
          if ( dwLastError6 < 0 )
          {
REPORT_FAILURE:
            wil::details::in1diag3::_Log_Hr(retaddr, 0x80D, v21, dwLastError6);
            continue;
          }
          if ( !*Data )                         // Result is stored at "Data": *Data=0x1 => CopyFile, if not: continue. 
                                                // So this is actually the #DogWalk vuln check.
            continue;
        }
        if ( CopyFileW(sWebDavFile, sTmpSDiagFile, 1) )// Vulnerable CopyFile op
        {
          dwLastError2 = 0;
        }
        else
        {
          dwLastError1 = GetLastError();
          dwLastError2 = dwLastError1 | 0x80070000;
          if ( dwLastError1 <= 0 )
            dwLastError2 = dwLastError1;
          if ( (dwLastError2 & 0x80000000) != 0 )
          {
            dwLastError3 = dwLastError2;
            itraceCode2 = 2151i64;
            goto DEBUG_TRACE5;
          }
        }
      }
    }
    while ( FindNextFileW(hFind, &FindFileData) );// File Search
  }
  operator delete(sWebDavFile);
  if ( sTmpSDiagFile )
    operator delete(sTmpSDiagFile);
  if ( (hFind - 1) <= 0xFFFFFFFFFFFFFFFDui64 )
    FindClose(hFind);
  return dwLastError2;
}

```

In summary what this function makes is:

1) Read TurnOffCheck setup.
2) Check arguments for any error.
3) Check if exist folders or files in WebDavRoot\\*, it continues if there are.
4) If TurnOffCheck setup then CopyFile without additional checkings.
5) Otherwise, check if any WebDav file is sub-directory of package source.
6) Then, check if any file is sub-directory of folder %TMP%\SDIAG_random-clsid. This is actually the vulnerability patch.
7) If *Data=1 then CopyFile, otherwise the file/folder searching continues.

Another interesting function to take a look into is sdiageng!SdpIsSubDirectory, the full pseudo-code:

```cpp

__int64 __fastcall SdpIsSubDirectory(const unsigned __int16 *aParentDir, const unsigned __int16 *aChildDir, int *aData)
{
  int *lData; // r14
  const unsigned __int16 *lChildDir; // r12
  wchar_t *sChildDir3; // rdi
  size_t iLenParentDir; // rsi
  unsigned __int64 iLenChildDir; // rbp
  __int64 itraceCode1; // r8
  signed int dwLastError1; // ebx
  signed int dwLastError4; // eax
  wchar_t *sParentDir2; // r15
  int dwLastError3; // er9
  __int64 itraceCode3; // r8
  signed int dwLastError5; // eax
  int dwLastError2; // er9
  __int64 itraceCode2; // r8
  __int64 iCharCounter1; // rdx
  wchar_t *sParentDir3; // rax
  __int64 iCharCounter2; // rdx
  wchar_t *sChildDir2; // rax
  wchar_t *sChildDir1; // [rsp+60h] [rbp+8h]
  wchar_t *sParentDir1; // [rsp+78h] [rbp+20h]

  lData = aData;
  sParentDir1 = 0i64;
  lChildDir = aChildDir;
  sChildDir1 = 0i64;
  sChildDir3 = 0i64;
  iLenParentDir = 0i64;
  iLenChildDir = 0i64;
  if ( !aParentDir )                            // Check arguments for errors
  {
    itraceCode1 = 1957i64;
DEBUG_TRACE1:
    dwLastError1 = -2147024809;
    SdpDebugTrace(1u, L"SdpIsSubDirectory", itraceCode1, -2147024809);
    return dwLastError1;
  }
  if ( !aChildDir )
  {
    itraceCode1 = 1958i64;
    goto DEBUG_TRACE1;
  }
  if ( !aData )
  {
    itraceCode1 = 1959i64;
    goto DEBUG_TRACE1;
  }
  dwLastError4 = SdpGetFullPath(aParentDir, &sParentDir1, 0i64);// Get Full path for parent directory
  sParentDir2 = sParentDir1;
  dwLastError1 = dwLastError4;
  if ( dwLastError4 >= 0 )
  {
    dwLastError5 = SdpGetFullPath(lChildDir, &sChildDir1, 0i64);// Get Full path for child directory
    dwLastError1 = dwLastError5;
    if ( dwLastError5 >= 0 )
    {
      if ( sParentDir2 )
      {
        iCharCounter1 = 260i64;
        sParentDir3 = sParentDir2;
        do                                      // Calculate length for parent directory
        {
          if ( !*sParentDir3 )
            break;
          ++sParentDir3;
          --iCharCounter1;
        }
        while ( iCharCounter1 );
        dwLastError1 = iCharCounter1 == 0 ? 0x80070057 : 0;
        if ( iCharCounter1 )
          iLenParentDir = 260 - iCharCounter1;
      }
      else
      {
        dwLastError1 = -2147024809;
      }
      if ( dwLastError1 < 0 )
        iLenParentDir = 0i64;
      if ( dwLastError1 >= 0 )
      {
        sChildDir3 = sChildDir1;
        if ( sChildDir1 )
        {
          iCharCounter2 = 260i64;
          sChildDir2 = sChildDir1;
          do                                    // Calculate length for child directory
          {
            if ( !*sChildDir2 )
              break;
            ++sChildDir2;
            --iCharCounter2;
          }
          while ( iCharCounter2 );
          dwLastError1 = iCharCounter2 == 0 ? 0x80070057 : 0;
          if ( iCharCounter2 )
            iLenChildDir = 260 - iCharCounter2;
        }
        else
        {
          dwLastError1 = -2147024809;
        }
        if ( dwLastError1 < 0 )
          iLenChildDir = 0i64;
        if ( dwLastError1 >= 0 )
        {                                       // 1) Len for child dir > Len for parent dir
                                                // 2) _wcsnicmp: Child dir begins with parent dir. Parent dir: %tmp%\SDIAG_random-clsid
                                                // 3) Last char of parent dir is "\" or next char for child dir, 
                                                // further than parent dir length, is "\" and exist further chars after this.
          *lData = iLenChildDir > iLenParentDir
                && !_wcsnicmp(sParentDir2, sChildDir1, iLenParentDir)
                && (sParentDir2[iLenParentDir - 1] == '\\'
                 || sChildDir3[iLenParentDir] == '\\' && sChildDir3[iLenParentDir + 1]);
          goto CLEANUP;
        }
        dwLastError3 = dwLastError1;
        itraceCode3 = 1971i64;
        goto DEBUG_TRACE2;
      }
      dwLastError2 = dwLastError1;
      itraceCode2 = 1968i64;
    }
    else
    {
      dwLastError2 = dwLastError5;
      itraceCode2 = 1965i64;
    }
    SdpDebugTrace(1u, L"SdpIsSubDirectory", itraceCode2, dwLastError2);
    sChildDir3 = sChildDir1;
    goto CLEANUP;
  }
  dwLastError3 = dwLastError4;
  itraceCode3 = 1962i64;
DEBUG_TRACE2:
  SdpDebugTrace(1u, L"SdpIsSubDirectory", itraceCode3, dwLastError3);
CLEANUP:
  if ( sParentDir2 )
    operator delete(sParentDir2);
  if ( sChildDir3 )
    operator delete(sChildDir3);
  return dwLastError1;
}

```

In summary:

1) Check for arguments for any error.
2) Get full path for parent directory.
3) Get full path for child directory.
4) Calculate string length for parent dir.
5) Calculate string length for child dir.
6) Check if child dir is really a child of parent dir. In fact, this is the interesting part where the "*Data" value is written:

```cpp

        if ( dwLastError1 >= 0 )
        {                                       // 1) Len for child dir > Len for parent dir
                                                // 2) _wcsnicmp: Child dir begins with parent dir. Parent dir: %tmp%\SDIAG_random-clsid
                                                // 3) Last char of parent dir is "\" or next char for child dir, 
                                                // further than parent dir length, is "\" and exist further chars after this.
          *lData = iLenChildDir > iLenParentDir
                && !_wcsnicmp(sParentDir2, sChildDir1, iLenParentDir)
                && (sParentDir2[iLenParentDir - 1] == '\\'
                 || sChildDir3[iLenParentDir] == '\\' && sChildDir3[iLenParentDir + 1]);
          goto CLEANUP;
        }

```

For some hours, i was unable to understand why they are checking the app-controlled string (sParentDir2) which is actually used against the attacker-controlled string (sChildDir1) in the function _wcsnicmp, until i took a look at the pseudo-diffing of this function (pre-patch vs post-patch). **This function is the same without any change**, according to diaphora:

![alt text](<./shots/sdiageng-best-matches.png>)

So **they are just reusing code that already exists in the library** xD This makes the things a bit more tricky from the patch diffing's point of view.

![alt text](<./shots/pseudocode-diffing-SdpIsSubDirectory.png>)

**The patch works fine IMO. Glad this finally got fixed by Microsoft, a bit late yup but better late than never. Thank you all to those who helped me to make noise enough to get this bug fixed :-)**

:clap: :clap: :clap: :muscle: :muscle: :pray:

By [@j00sean](https://twitter.com/j00sean)
