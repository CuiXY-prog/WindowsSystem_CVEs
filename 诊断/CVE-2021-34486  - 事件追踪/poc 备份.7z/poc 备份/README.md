# CVE-2021-34486
 Windows Etw LPE
 
olny tested on windwos 20H2 x64

ed2k://|file|cn_windows_10_business_editions_version_20h2_updated_march_2021_x64_dvd_ca61aaaa.iso|6074574848|B6741C4E4B09337471B02DC95E953992|/

thanks @yongchuank

https://www.pixiepointsecurity.com/blog/advisory-cve-2021-34486.html


![image]( https://github.com/KaLendsi/CVE-2021-34486/blob/main/exploit.gif)
