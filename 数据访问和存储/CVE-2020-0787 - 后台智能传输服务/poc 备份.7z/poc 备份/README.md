# CVE-2020-0787-EXP-ALL-WINDOWS-VERSION

#### 申明 ####

作者poc仅供研究目的,如果读者利用本poc从事其他行为,与本人无关

#### 介绍
CVE-2020-0787-EXP Support ALL Windows Version

![pic](https://ftp.bmp.ovh/imgs/2020/06/bcf797d23480bb10.png)
