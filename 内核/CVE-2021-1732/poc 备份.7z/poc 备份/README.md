# CVE-2021-1732-Exploit
CVE-2021-1732 Exploit

Only tested on windows10 1909 x64

![image]( https://github.com/KaLendsi/CVE-2021-1732-Exploit/blob/main/exploit.gif)
