﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace NtDataPoc
{
    public class HardLink
    {

        private static IntPtr Emit_UNICODESTRING(string data)
        {
            UNICODE_STRING UnicodeObject = new NtDataPoc.UNICODE_STRING();
            UnicodeObject.Length = (UInt16)(data.Length * 2);
            UnicodeObject.MaximumLength = (UInt16)(data.Length + 1);
            UnicodeObject.Buffer = Marshal.StringToHGlobalUni(data);
            IntPtr InMemoryStruct = Marshal.AllocHGlobal(16);
            Marshal.StructureToPtr(UnicodeObject, InMemoryStruct, true);
            return InMemoryStruct;
        }


        private static string GetFullPathName(string path)
        {
            string fullPath = "";
            StringBuilder lpBuffer = new StringBuilder();
            IntPtr fnPortionAddress = IntPtr.Zero;
            UInt32 result = NtHardLink.GetFullPathName(path, 1, lpBuffer, ref fnPortionAddress);

            if (result != 0)
            {
                int minCapacity = lpBuffer.EnsureCapacity((int)result);
                result = NtHardLink.GetFullPathName(path, (UInt32)lpBuffer.Capacity, lpBuffer, ref fnPortionAddress);
                fullPath = @"\??\" + lpBuffer.ToString();
                //fullPath = lpBuffer.ToString();
            }
            else
            {
                //big fail
                return "";
            }
            return fullPath;
        }


        private static IntPtr GetNativeFileHandle(string path)
        {
            IntPtr handle = IntPtr.Zero, hFile = IntPtr.Zero;
            string fullPath = GetFullPathName(path);
            if(!string.IsNullOrEmpty(path))
            {
                /*if(!File.Exists(path))
                {
                    Console.WriteLine("[!] Invalid file path specified..");
                    return handle;
                }*/
            }
            else
            {
                Console.WriteLine("[!] Failed to retrieve fully qualified path..");
                return handle;
            }
            // Prepare NtOpenFile params
            OBJECT_ATTRIBUTES objAttr = new OBJECT_ATTRIBUTES();
            objAttr.Length = Marshal.SizeOf(objAttr);
            objAttr.ObjectName = Emit_UNICODESTRING(fullPath);
            objAttr.Attributes = 0x40;
            //objAttr.
            IO_STATUS_BLOCK ioStatusBlock = new IO_STATUS_BLOCK();

            // DesiredAccess = MAXIMUM_ALLOWED; ShareAccess = FILE_SHARE_READ
            UInt32 callResult = NtHardLink.NtOpenFile(ref hFile,0x02000000,ref objAttr,ref ioStatusBlock,0x1,0x0) ;
            //UInt32 callResult = NtHardLink.NtOpenFile(ref hFile, 0x80000000, ref objAttr, ref ioStatusBlock, 0x0, 0x0);
            if (callResult==0)
            {
                handle = hFile;
            }
            else
            {
                Console.WriteLine("[!] Failed to acquire file handle, NTSTATUS({0:X}).." , callResult );
            }
            return handle;
        }


        public static bool CreateNtHardLink(string link, string target, uint FileLinkInformation = 0xB)
        {
            string linkFullPath = GetFullPathName(link);
            // IO.* does not support full path name on Win7
            string linkParent = System.IO.Directory.GetParent(link).FullName;

            if (!System.IO.Directory.Exists(linkParent))
            {
                Console.WriteLine("[!] Invalid link folder path specified..");
                return false;
            }

            FILE_LINK_INFORMATION fileLinkInformation = new FILE_LINK_INFORMATION();
            fileLinkInformation.ReplaceIfExists = true;
            fileLinkInformation.FileName = linkFullPath;
            fileLinkInformation.RootDirectory = IntPtr.Zero;
            fileLinkInformation.FileNameLength = (UInt32)linkFullPath.Length * 2;
            int fileLinkInformationLen = System.Runtime.InteropServices.Marshal.SizeOf(fileLinkInformation);
            IntPtr pFileLinkInformation = System.Runtime.InteropServices.Marshal.AllocHGlobal(fileLinkInformationLen);

            System.Runtime.InteropServices.Marshal.StructureToPtr(fileLinkInformation, pFileLinkInformation, true);
            IO_STATUS_BLOCK ioStatusBlock = new IO_STATUS_BLOCK();

            // Get handle to target
            IntPtr hTarget = GetNativeFileHandle(target);
            if (hTarget == IntPtr.Zero) {
                Console.WriteLine("[!] Couldnt get file handle {0} ..", target);
                return false;
            }

            // FileInformationClass => FileLinkInformation = 0xB
            UInt32 result = NtHardLink.NtSetInformationFile(hTarget, ref ioStatusBlock, pFileLinkInformation, (UInt32)fileLinkInformationLen, 0xB);
            //UInt32 result = NtHardLink.NtSetInformationFile(hTarget, ref ioStatusBlock, pFileLinkInformation, (UInt32)fileLinkInformationLen, FileLinkInformation);
            if (result==0)
            {
                // everything is OK
                bool bResult = NtHardLink.CloseHandle(hTarget);
                return true;
            } else
            {
                Console.WriteLine("[!] Failed to create hardlink, NTSTATUS({0:X})..", result);
                bool bResult = NtHardLink.CloseHandle(hTarget);
                return false;
            }
            
        }

    }
}
