# CVE-2022-21882

Win32k Elevation of Privilege Vulnerability

For Windows 10 21H2 Only

![](https://raw.githubusercontent.com/L4ys/CVE-2022-21882/main/CVE-2022-21882.png)
