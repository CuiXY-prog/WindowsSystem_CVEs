Working in WIN10 1903 Not a perfect exp



https://bbs.pediy.com/thread-271140.htm
