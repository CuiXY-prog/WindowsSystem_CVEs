//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ACLtakeoverLPE2.rc
//
#define IDR_RCDATA1                     101
#define IDR_RCDATA2                     102
#define IDR_RCDATA3                     103
#define IDR_RCDATA4                     104
#define IDR_RCDATA5                     105

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
